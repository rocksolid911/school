import 'package:flutter/cupertino.dart';
//import 'package:phygitalz_project_1/Auth/models/User.dart';
// import 'package:phygitalz_project_1/Auth/models/Userprovider.dart';
// import 'package:provider/provider.dart';
//
// class HssBody extends StatefulWidget {
//   const HssBody({Key key}) : super(key: key);
//
//   @override
//   _HssBodyState createState() => _HssBodyState();
// }
//
// class _HssBodyState extends State<HssBody> {
//   @override
//   Widget build(BuildContext context) {
//    // User user = Provider.of<UserProvider>(context).user;
//
//     return Container(
//       child: Center(child: Text(user.emailId.toString())),
//     );
//   }
// }
