import 'package:flutter/material.dart';
class ForgotPasswd extends StatefulWidget {
  const ForgotPasswd({Key key}) : super(key: key);

  @override
  _ForgotPasswdState createState() => _ForgotPasswdState();
}

class _ForgotPasswdState extends State<ForgotPasswd> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
