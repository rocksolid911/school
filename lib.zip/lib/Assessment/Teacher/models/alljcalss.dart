class AllAssJclass {
  String allJsa(){
    String er = """
    
[{
"S40_Assessment_ID":"1",
 "S40_Class_Id":"10",
"S40_Class_Section":"B",
 "S40_Subject_Id":"A1",
"S40_Subject_Name":"Mathematics",
"S40_Assessment_Name":"Summative 2",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Rammohan",
"S40_Max_Score":"100",
"S40_Current_Score":"80",
 "S40_Type":"Periodic",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"21 Oct 2021",
"S40_Start_Time":"2.30 pm",
"S40_End_Time":"4.30 pm",
"S40_Status":"",
"S40_Remarks":"Date changed,Grammar Mistake",
"S40_Response":"",
"S40_Average_Score":"70"
},




{
"S40_Assessment_ID":"2",
 "S40_Class_Id":"10",
"S40_Class_Section":"C",
 "S40_Subject_Id":"C3",
"S40_Subject_Name":"Chemistry",
"S40_Assessment_Name":"Summative 1",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Roshan KK",
"S40_Max_Score":"100",
"S40_Current_Score":"70",
 "S40_Type":"Summative",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"21 Dec 2021",
"S40_Start_Time":"1.30 pm",
"S40_End_Time":"4.00 pm",
"S40_Status":"",
"S40_Remarks":"Improve little bit",
"S40_Response":"",
"S40_Average_Score":"60"
},




{
"S40_Assessment_ID":"3",
 "S40_Class_Id":"10",
"S40_Class_Section":"B",
 "S40_Subject_Id":"D3",
"S40_Subject_Name":"Physics",
"S40_Assessment_Name":"Summative 1",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Jerry Joy",
"S40_Max_Score":"100",
"S40_Current_Score":"90",
 "S40_Type":"Periodic",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"21 Aug 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Excellent job",
"S40_Response":"",
"S40_Average_Score":"60"
},


{
"S40_Assessment_ID":"4",
 "S40_Class_Id":"9",
"S40_Class_Section":"C",
 "S40_Subject_Id":"A5",
"S40_Subject_Name":"Biological Sciences",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Rahul Roy",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Class",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"03 Jul 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.00 am",
"S40_Status":"",
"S40_Remarks":"Improve your handwriting.Attend the test only after adequate preperation.",
"S40_Response":"",
"S40_Average_Score":"60"
},


{
"S40_Assessment_ID":"5",
 "S40_Class_Id":"12",
"S40_Class_Section":"C",
 "S40_Subject_Id":"D2",
"S40_Subject_Name":"Computer Science",
"S40_Assessment_Name":"Unit 1",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Sheela",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"21 Aug 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.00 am",
"S40_Status":"Draft",
"S40_Remarks":"Contact Teacher",
"S40_Response":"",
"S40_Average_Score":"60"
},

{
"S40_Assessment_ID":"6",
 "S40_Class_Id":"11",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B11",
"S40_Subject_Name":"Anthropology",
"S40_Assessment_Name":"Unit 1",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Shanmuki",
"S40_Max_Score":"80",
"S40_Current_Score":"78",
 "S40_Type":"Periodic",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"21 Aug 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.00 am",
"S40_Status":"",
"S40_Remarks":"Excellent job.Keep it up",
"S40_Response":"",
"S40_Average_Score":"60"
},




{
"S40_Assessment_ID":"7",
 "S40_Class_Id":"11",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B7",
"S40_Subject_Name":"Humanities",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Roy Mathew",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Summative",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"04 Jul 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.00 am",
"S40_Status":"",
"S40_Remarks":"You could have read the textbook before attending the test.",
"S40_Response":"",
"S40_Average_Score":"60"
},



{
"S40_Assessment_ID":"7",
 "S40_Class_Id":"10",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B2",
"S40_Subject_Name":"Hindi",
"S40_Assessment_Name":"Summative 3",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Jobin George",
"S40_Max_Score":"100",
"S40_Current_Score":"80",
 "S40_Type":"Periodic",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"08 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Good work.Keep it up.",
"S40_Response":"",
"S40_Average_Score":"60"
},




{
"S40_Assessment_ID":"8",
 "S40_Class_Id":"10",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B4",
"S40_Subject_Name":"English",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Anwar Ali",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"08 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Good work.Keep it up.Have to go to the Grammar parts once more",
"S40_Response":"",
"S40_Average_Score":"60"
},





{
"S40_Assessment_ID":"9",
 "S40_Class_Id":"09",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B5",
"S40_Subject_Name":"Economics",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Saurav Roy",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"08 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Contact the teacher immediately.",
"S40_Response":"",
"S40_Average_Score":"60"
},




{
"S40_Assessment_ID":"10",
 "S40_Class_Id":"10",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B6",
"S40_Subject_Name":"History",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Babu John",
"S40_Max_Score":"100",
"S40_Current_Score":"50",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"18 Jun 2021",
"S40_Start_Time":"11.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Good work.Have to improve.",
"S40_Response":"",
"S40_Average_Score":"60"
},






{
"S40_Assessment_ID":"11",
 "S40_Class_Id":"11",
"S40_Class_Section":"B",
 "S40_Subject_Id":"B6",
"S40_Subject_Name":"History",
"S40_Assessment_Name":"Summative 6",
"S40_Title":"",
"S40_Teacher_Name":"Mr.John Joy",
"S40_Max_Score":"100",
"S40_Current_Score":"80",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"09 Jun 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Have to read about Henry Fayol and compare it with question number 6",
"S40_Response":"",
"S40_Average_Score":"60"
},









{
"S40_Assessment_ID":"12",
 "S40_Class_Id":"12",
"S40_Class_Section":"C",
 "S40_Subject_Id":"B9",
"S40_Subject_Name":"Public Administration",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Seema Mathew",
"S40_Max_Score":"100",
"S40_Current_Score":"70",
 "S40_Type":"Periodic",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"08 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"01.00 pm",
"S40_Status":"",
"S40_Remarks":"Read about Henry Fayol and compare it with your answer for Question Number 5.",
"S40_Response":"",
"S40_Average_Score":"60"
},




{
"S40_Assessment_ID":"13",
 "S40_Class_Id":"12",
"S40_Class_Section":"C",
 "S40_Subject_Id":"F1",
"S40_Subject_Name":"Political Science",
"S40_Assessment_Name":"Summative",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Rani Laxmi",
"S40_Max_Score":"100",
"S40_Current_Score":"22",
 "S40_Type":"Periodic",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"04 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"12.00 pm",
"S40_Status":"",
"S40_Remarks":"Inform your parents for meeting the Principal immediately.",
"S40_Response":"",
"S40_Average_Score":"60"
},





{
"S40_Assessment_ID":"14",
 "S40_Class_Id":"10",
"S40_Class_Section":"D",
 "S40_Subject_Id":"F2",
"S40_Subject_Name":"Psychology",
"S40_Assessment_Name":"Class Test",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Anjana Kappan",
"S40_Max_Score":"100",
"S40_Current_Score":"89",
 "S40_Type":"Class",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"04 Jun 2021",
"S40_Start_Time":"10.00 am",
"S40_End_Time":"12.00 pm",
"S40_Status":"Approved",
"S40_Remarks":"Excellent job.",
"S40_Response":"",
"S40_Average_Score":"60"
},


{
"S40_Assessment_ID":"14",
 "S40_Class_Id":"10",
"S40_Class_Section":"D",
 "S40_Subject_Id":"F3",
"S40_Subject_Name":"Psychology",
"S40_Assessment_Name":"Summative",
"S40_Title":"",
"S40_Teacher_Name":"Mr.Kumar KC",
"S40_Max_Score":"100",
"S40_Current_Score":"89",
 "S40_Type":"Periodic",
 "S40_Term":"Term 2",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"09 Apr 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.30 pm",
"S40_Status":"Draft",
"S40_Remarks":"Great Work.",
"S40_Response":"",
"S40_Average_Score":"60"
},







{
"S40_Assessment_ID":"15",
 "S40_Class_Id":"11",
"S40_Class_Section":"C",
 "S40_Subject_Id":"F5",
"S40_Subject_Name":"Social Issues",
"S40_Assessment_Name":"Summative",
"S40_Title":"",
"S40_Teacher_Name":"Mrs.Angel Mary",
"S40_Max_Score":"100",
"S40_Current_Score":"89",
 "S40_Type":"Periodic",
 "S40_Term":"Term 1",
"S40_Attend_Assess_Via":"",
"S40_Ans_Method":"",
"S40_Assess_Pattern_Id":"",
"S40_Instructions":"",
 "S40_Lesson_Id":"",
"S40_Lesson_Name":"",
"S40_Schedule_Date":"09 Apr 2021",
"S40_Start_Time":"09.00 am",
"S40_End_Time":"12.30 pm",
"S40_Status":"Draft",
"S40_Remarks":"Great Work.",
"S40_Response":"",
"S40_Average_Score":"60"
}



]





     """;
    return er;
  }
}