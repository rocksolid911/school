class EvJclass {
  String ejsa(){
    String er = """ 
    {
    "Given_Exam": [
        {
            "S40_Student_Name": "Rohit Sharma",
            "S40_User_Roll_Number": "11",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "30/70",
            "S40_Percentage": "42.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Poor",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 49
        },
        {
            "S40_Student_Name": "Ankita Sahoo",
            "S40_User_Roll_Number": "12",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "60/70",
            "S40_Percentage": "80.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Excellent",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 50
        },
        {
            "S40_Student_Name": "Arnab sarangi",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 51
        },
         {
            "S40_Student_Name": "Rashmi sarangi",
            "S40_User_Roll_Number": "16",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "30/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "fair",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 52
        },
         {
            "S40_Student_Name": "Adweit mishra",
            "S40_User_Roll_Number": "17",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "55/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 53
        },
         {
            "S40_Student_Name": "Siddhant saraf",
            "S40_User_Roll_Number": "21",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 54
        },
         {
            "S40_Student_Name": "adaddk kkdkk",
            "S40_User_Roll_Number": "108",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "42/70",
            "S40_Percentage": "67.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "fair",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 55
        },
         {
            "S40_Student_Name": "raja babu",
            "S40_User_Roll_Number": "109",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "60/70",
            "S40_Percentage": "90.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Excellent",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 56
        },
         {
            "S40_Student_Name": "Arnab sarangi",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 57
        },
         {
            "S40_Student_Name": "Nisi raja",
            "S40_User_Roll_Number": "106",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "46/70",
            "S40_Percentage": "57.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 58
        },
         {
            "S40_Student_Name": "Swarup sarangi",
            "S40_User_Roll_Number": "104",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "54/70",
            "S40_Percentage": "62.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Not Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 59
        },
         {
            "S40_Student_Name": "Sumit Panigrahi",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "45/70",
            "S40_Percentage": "64.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "fair",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 60
        },
        {
            "S40_Student_Name": "Prasad Babu",
            "S40_User_Roll_Number": "94",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "45/70",
            "S40_Percentage": "60.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 61
        },
        {
            "S40_Student_Name": "Eswar raman",
            "S40_User_Roll_Number": "84",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "70/70",
            "S40_Percentage": "100",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Excellent",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 62
        },
        {
            "S40_Student_Name": "Aswin raja",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "65/70",
            "S40_Percentage": "85.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Excellent",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 63
        },
        {
            "S40_Student_Name": "asdd kdfkd",
            "S40_User_Roll_Number": "28",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Rejected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 64
        },
        {
            "S40_Student_Name": "jhdjwh ndjwj",
            "S40_User_Roll_Number": "44",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Rejected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 65
        },
        {
            "S40_Student_Name": "Satya saraf",
            "S40_User_Roll_Number": "74",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "15/70",
            "S40_Percentage": "17.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Poor",
            "S40_Assess_Ans_Status": "Not Turnedin",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 66
        },
        {
            "S40_Student_Name": "Rajat Mishra",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Not Turnedin",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 67
        },
        {
            "S40_Student_Name": "Amit Panigrahi",
            "S40_User_Roll_Number": "34",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Not Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 68
        },
        {
            "S40_Student_Name": "Ansupa Sahoo",
            "S40_User_Roll_Number": "57",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 69
        },
        {
            "S40_Student_Name": "Sudha Dip",
            "S40_User_Roll_Number": "38",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "25/70",
            "S40_Percentage": "32.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Poor",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 70
        },
         {
            "S40_Student_Name": "Raghu Dip",
            "S40_User_Roll_Number": "17",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "20/70",
            "S40_Percentage": "30.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "poor",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 71
        },
         {
            "S40_Student_Name": "Rama Panigrahi",
            "S40_User_Roll_Number": "44",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "58/70",
            "S40_Percentage": "78.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Not Turnedin",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 72
        },
         {
            "S40_Student_Name": "Namita Patel",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Rejected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 73
        },
         {
            "S40_Student_Name": "Aswin Singh",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Rejected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 74
        },
         {
            "S40_Student_Name": "zRasmita Nag",
            "S40_User_Roll_Number": "14",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "40/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "fair",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 75
        },
         {
            "S40_Student_Name": "Raman Raghab",
            "S40_User_Roll_Number": "62",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "54/70",
            "S40_Percentage": "74.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 76
        },
         {
            "S40_Student_Name": "Ragharv ranjan",
            "S40_User_Roll_Number": "45",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Not Turnedin",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 77
        },
         {
            "S40_Student_Name": "Dharanidhra rout",
            "S40_User_Roll_Number": "52",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Excellent",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 78
        },
         {
            "S40_Student_Name": "Biswajit Panigrahi",
            "S40_User_Roll_Number": "44",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "NOT Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 79
        },
         {
            "S40_Student_Name": "Paridhi nana",
            "S40_User_Roll_Number": "24",
            "S40_Document": [
                {
                    "S40_Document_Name": "Updated Test 1",
                    "S40_Document_Base64": "",
                    "S40_Document_Format": "pdf"
                }
            ],
            "S40_Marks": "50/70",
            "S40_Percentage": "70.86",
            "S40_Time_Taken": "01:20:30",
            "S40_Is_Corrected": "Yes",
            "S40_Student_Grade": "Good",
            "S40_Assess_Ans_Status": "Corrected",
            "S40_Created_Date": "2021-03-29",
            "S40_Last_Modified_Date": "2021-03-30",
            "S40_User_Id": 80
        }
    ],
    "Not_Given_Exam": [
        {
            "S40_User_Roll_Number": "9002",
            "S40_Student_Name": "FirstName LastName",
            "S40_Reason": "Absent",
            "S40_User_Id": 50
        },
        {
            "S40_User_Roll_Number": "9003",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 51
        },
        {
            "S40_User_Roll_Number": "9004",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 52
        },
        {
            "S40_User_Roll_Number": "9005",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 53
        },
        {
            "S40_User_Roll_Number": "9006",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 54
        },
        {
            "S40_User_Roll_Number": "9007",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 55
        },
        {
            "S40_User_Roll_Number": "9008",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 55
        },
        {
            "S40_User_Roll_Number": "9009",
            "S40_Student_Name": "Fname Lname",
            "S40_Reason": "Absent",
            "S40_User_Id": 56
        }
    ]
}
""";

    return er;
  }
}