class jclas {
  String jsa() {
    String er = """ {
    "assignments": [
      { 
          "S40_School_Branch":"1",
      "S40_Class_Section":"10A",
      "S40_Subject":"physics",
      "S40_Lessons":"2",
      "S40_Topics":"Gravity",
      "S40_Assignment_Type":"Lab Record",
      "S40_Assignment_Details":"Submit an assignment on Gravity before due date",
      "S40_Assigned_Date":"2021-03-29",
      "S40_Due_Date":"2021-03-31",
      "S40_Assignment_Status":"Pending",
      "S40_Created_By":"Mr.Manu Mohan",
      "S40_Document":[
        {"Document_Base64":"","Document_Name":"lab-1","Document_Format":""}
      ],
      "reference_links_list":[
        {"url":"https://www.google.com"}
      ],
      "action":"create"
    },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10B",
        "S40_Subject":"Mathematics",
        "S40_Lessons":"1",
        "S40_Topics":"Algebra",
        "S40_Assignment_Type":"Port Folio",
        "S40_Assignment_Details":"Refer the Internet to find various concepts of Algebra and create a Port Folio for the same.",
        "S40_Assigned_Date":"2021-04-11",
        "S40_Due_Date":"2021-04-25",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Rahul C V",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"port-1","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"Tamil",
        "S40_Lessons":"2",
        "S40_Topics":"Importance of Mother Toungue",
        "S40_Assignment_Type":"Port Folio",
        "S40_Assignment_Details":"Read the teachers' Feedback on your submitted Port Folio and make the suggested changes.",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Published",
        "S40_Created_By":"Mr.Alex P John",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"port-2","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10C",
        "S40_Subject":"Computer Science",
        "S40_Lessons":"3",
        "S40_Topics":"Evolution of Modern Computer",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Explore on the evolution of Modern Computer and submit the analysis of the same before the due date.",
        "S40_Assigned_Date":"2021-04-19",
        "S40_Due_Date":"2021-04-31",
        "S40_Assignment_Status":"Pending",
        "S40_Created_By":"Ms.Anna Joy",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-1","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10B",
        "S40_Subject":"English",
        "S40_Lessons":"1",
        "S40_Topics":"Verbs,Noun and Pronouns",
        "S40_Assignment_Type":"Port Folio",
        "S40_Assignment_Details":"Create a Port Folio containing the usage of given topic with Suitable examples.",
        "S40_Assigned_Date":"2021-05-29",
        "S40_Due_Date":"2021-05-31",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Rafi CP",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"port-3","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {"S40_School_Branch":"1",
        "S40_Class_Section":"10D",
        "S40_Subject":"Biology",
        "S40_Lessons":"1",
        "S40_Topics":"Human Respiratory System",
        "S40_Assignment_Type":"Lab Record",
        "S40_Assignment_Details":"As you are aware that frogs have similar respiratory systems as that of Humans,examine it practicallywith a frog and create a Lab Record on the similarities and diffrences between respiratory system of frogs and humans.",
        "S40_Assigned_Date":"2021-07-15",
        "S40_Due_Date":"2021-07-27",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Babu K Antony",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"lab-2","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10B",
        "S40_Subject":"Hindi",
        "S40_Lessons":"1",
        "S40_Topics":"Environment Protection",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Environment in the modern times is on the brink of destruction.Comment",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Ms.Rajasree",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-2","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {"S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"English",
        "S40_Lessons":"1",
        "S40_Topics":"Communication",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Explain the key ways for achieving efficient communication skills.",
        "S40_Assigned_Date":"2021-07-27",
        "S40_Due_Date":"2021-07-29",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Rafi CP",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-3","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {"S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"Philosophy",
        "S40_Lessons":"1",
        "S40_Topics":"Human Mind",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Explain the description of Human Mind by Aristotle and comment your views on the same.",
        "S40_Assigned_Date":"2021-02-12",
        "S40_Due_Date":"2021-02-15",
        "S40_Assignment_Status":"Pending",
        "S40_Created_By":"Mr.Ashwin M",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-4","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10C",
        "S40_Subject":"Political Science",
        "S40_Lessons":"1",
        "S40_Topics":"Capitalism and Communism",
        "S40_Assignment_Type":"Port Folio",
        "S40_Assignment_Details":"'After Globalisation,Communism has totally been replaced by Capitalism'.Create a Port Folio explaining the statement with suitable examples.",
        "S40_Assigned_Date":"2021-03-03",
        "S40_Due_Date":"2021-03-07",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Ms.Jiji Thomas",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"port-4","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"Chemistry",
        "S40_Lessons":"1",
        "S40_Topics":"Evolution of Atomic Model",
        "S40_Assignment_Type":"Lab Record",
        "S40_Assignment_Details":"Science of Atomic Model has been evolved to a great extend on recent years.Explain various aspects and Evolution of Modern Atomic Model.",
        "S40_Assigned_Date":"2021-04-04",
        "S40_Due_Date":"2021-04-08",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Manu Baby",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"lab-3","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10D",
        "S40_Subject":"Economics",
        "S40_Lessons":"1",
        "S40_Topics":"Five year plan",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"'First five year plan was a failure'.Comment on the statement",
        "S40_Assigned_Date":"2021-05-26",
        "S40_Due_Date":"2021-05-31",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Saurav Sudhakar",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-5","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"History",
        "S40_Lessons":"1",
        "S40_Topics":"Cold War",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Someone once said 'Cold War hasn't end,rather it was a beginning'.Examine the statement.",
        "S40_Assigned_Date":"2021-05-29",
        "S40_Due_Date":"2021-05-31",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Ms.Savitri",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-6","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10C",
        "S40_Subject":"Tamil",
        "S40_Lessons":"1",
        "S40_Topics":"Son of Soil",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Sweat of a farmer is behind every single morsel that we have,however farmer suicide is increasing in our country.Site the reasons ",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Draft",
        "S40_Created_By":"Mr.Alex P John",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-7","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"Geography",
        "S40_Lessons":"1",
        "S40_Topics":"Plate Tectonics",
        "S40_Assignment_Type":"Port Folio",
        "S40_Assignment_Details":"Review the feedback and meet the tutor.",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Published",
        "S40_Created_By":"Mr.Tony K",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"port-5","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10D",
        "S40_Subject":"Chemistry",
        "S40_Lessons":"1",
        "S40_Topics":"Particulate Matter",
        "S40_Assignment_Type":"Home work",
        "S40_Assignment_Details":"Meet the Teacher.",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Pending",
        "S40_Created_By":"Mr.Many Baby",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"hwork-8","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      },
      {
        "S40_School_Branch":"1",
        "S40_Class_Section":"10A",
        "S40_Subject":"Physics",
        "S40_Lessons":"1",
        "S40_Topics":"Theory of Relativity",
        "S40_Assignment_Type":"Lab Record",
        "S40_Assignment_Details":"Contact your teacher.",
        "S40_Assigned_Date":"2021-03-29",
        "S40_Due_Date":"2021-03-31",
        "S40_Assignment_Status":"Published",
        "S40_Created_By":"Mr.Manu Mohan",
        "S40_Document":[
          {"Document_Base64":"","Document_Name":"lab-4","Document_Format":""}
        ],
        "reference_links_list":[
          {"url":"https://www.google.com"}
        ],
        "action":"create"
      }
    ]
  }
  """;
    return er;
  }
}
