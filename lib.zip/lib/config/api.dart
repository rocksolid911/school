final String _path = "http://13.232.236.195/school4.0_loc/";


String serverPath = "${_path}api/V1/";
String serverImages = "${_path}public/images/";
String serverImgNoUserPath = "${_path}public/img/user.png";
